#ifndef REPROC_C_WINDOWS_HANDLE_H
#define REPROC_C_WINDOWS_HANDLE_H

#include <windows.h>

void handle_close(HANDLE *handle);

#endif
